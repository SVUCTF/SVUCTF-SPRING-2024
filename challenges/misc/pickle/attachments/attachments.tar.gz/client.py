import socket
import pickle
import time
import psutil

INTERVAL_TIME = 1
IP = "127.0.0.1"
PORT = 8848


class Info:
    def __init__(
        self,
        time=None,
        cpu_count=None,
        cpu_percent=None,
        mem_total=None,
        mem_available=None,
        mem_percent=None,
        disk_total=None,
        disk_used=None,
        disk_free=None,
        disk_percent=None,
        net_bytes_sent=None,
        net_bytes_recv=None,
        net_packets_sent=None,
        net_packets_recv=None,
    ) -> None:
        self.time = time
        self.cpu_count = cpu_count
        self.cpu_percent = cpu_percent
        self.mem_total = mem_total
        self.mem_available = mem_available
        self.disk_total = disk_total
        self.disk_used = disk_used
        self.disk_free = disk_free
        self.disk_percent = disk_percent
        self.mem_percent = mem_percent
        self.net_bytes_sent = net_bytes_sent
        self.net_bytes_recv = net_bytes_recv
        self.net_packets_sent = net_packets_sent
        self.net_packets_recv = net_packets_recv


def main():
    info = Info()

    client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client.connect((IP, PORT))

    while True:
        info.time = int(time.time())

        info.cpu_count = psutil.cpu_count()
        info.cpu_percent = psutil.cpu_percent()

        svmem = psutil.virtual_memory()
        info.mem_total = svmem.total
        info.mem_available = svmem.available
        info.mem_percent = svmem.percent

        sdiskusage = psutil.disk_usage("/home/")
        info.disk_total = sdiskusage.total
        info.disk_used = sdiskusage.used
        info.disk_free = sdiskusage.free
        info.disk_percent = sdiskusage.percent

        snetio = psutil.net_io_counters()
        info.net_bytes_sent = snetio.bytes_sent
        info.net_bytes_recv = snetio.bytes_recv
        info.net_packets_sent = snetio.packets_sent
        info.net_packets_recv = snetio.packets_recv

        data = pickle.dumps(info)
        data = len(data).to_bytes(4) + data

        client.send(data)

        time.sleep(INTERVAL_TIME)


if __name__ == "__main__":
    main()
